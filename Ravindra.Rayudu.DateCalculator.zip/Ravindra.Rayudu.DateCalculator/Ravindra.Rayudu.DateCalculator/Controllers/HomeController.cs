﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Ravindra.Rayudu.DateCalculator.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult AddDays(Models.CalculateDays calculateDays)
        {
            calculateDays.Days = (calculateDays.StartDate - calculateDays.EndDate).Days;
            return View("Index", calculateDays);
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";
            return View();
        }        

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";
            return View();
        }
    }
   
}